#High Level Design Diagram
========
![img.png](img.png)

#Technology
====
1.Java
2.SpringBoot
3.Mongo DB
4.Docker
5.Docker-compose
6.maven
7.Intellij
8.Junit & Mockito 

##swagger URL:
====
Integrated Swagger Below is the Link.

http://localhost:8080/swagger-ui.html

### monitoring:
======

Integrated micrometer and prometheus for Monitoring Purpose

http://localhost:8080/actuator/prometheus

##### Build maven and Run
===
1.clean ==>.\mvnw clean 
2.Build ==> .\mvnw package
3.Test ===> .\mvnw test
4.Install Mongo db local and run below command cmd propmt 
D:\Work\Softwares\mongodb-windows-x86_64-5.0.6\mongodb-win32-x86_64-windows-5.0.6\bin>mongod.exe --dbpath "D:\data"
5. Right click UserServiceAppApplication -> run
###Docker
====
1.Build Docker user-service-app
docker build -t  user-service-app .
2.Run And Expose port
docker run -p 8080:8080  user-service-app
3. For Mongo DataBase Run Locally
docker run -d  --name mongo-on-docker  -p 27888:27017 mongo

4.Run entire application include user-service-app,MongoDb
   up: docker-compose up -d
   down: docker-compose down
   logs: docker-compose logs user-service-app  
6.For connecting  application ,mongodb to host machine we need to use docker-machine ip
  docker-machine ip


###### App Deployment Assumptions
====
We can Deploy app into any Cloud provider like below(Docker base Deployment ).

1.GCP:
===
git-> jenkins(build, Test,docker image ) -> docker registry (GCR) ->Spinnaker (Push Base) -> GKE

2.AWS
===
AWS CodePipeline (buildspec.yml)  CodeCommit -> CodeBuild -> CodeDeploy (EKS)

## 3.AzureDevops
====
AzureDevops (azure-pipline.yml)  repo(git/azure repo) -->build-> ACR-> AKS

### 4.Onprem-Cloud -data center
=======
git-> jenkins(build, Test,docker image) -> Jforg ->Argo-CD(pull base)-> Kubernetes clusters


##Application /Improvement Ideas :
======
1.Write BDD Test Cases .
2.Include Tracing mechanism (like sleuth)