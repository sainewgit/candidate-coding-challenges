package com.user.service;

import com.user.entity.User;
import com.user.exception.UserNotFoundException;
import com.user.repository.UserRepository;
import com.user.transformer.ToUserViewTransformer;
import com.user.view.UserView;
import org.junit.After;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;
import java.util.UUID;

import static com.shazam.shazamcrest.MatcherAssert.assertThat;
import static com.user.util.UserTestDataUtil.newRandomUser;
import static com.user.util.UserTestDataUtil.newRandomUserView;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {
    @Mock
    private UserRepository userRepository;
    @Mock
    private ToUserViewTransformer toUserViewTransformer;
    @InjectMocks
    private UserService userService;

    @After
    public void afterTest() {
        reset(userRepository);
        reset(toUserViewTransformer);
    }

    @Test
    public void shouldReturnNotFoundExceptionByUserId() {
        //given
        String userId = UUID.randomUUID().toString();

        String expectedMessage = "cannot find User with id:" + userId;

        given(userRepository.findById(userId)).willReturn(Optional.ofNullable(null));

        //when
        Exception actualException = assertThrows(UserNotFoundException.class, () -> {
            userService.getUserById(userId);
        });
        //then
        assertTrue(actualException.getMessage().contains(expectedMessage));
    }

    @Test
    public void shouldCreateUser() {

        // given
        String userId = UUID.randomUUID().toString();
        User user = newRandomUser(userId);

        given(userRepository.save(user)).willReturn(user);

        // when
        String actualId = userService.saveUser(user);
        // then
        assertThat(actualId, is(userId));
    }

    @Test
    public void shouldDeleteUserWhenMatchFound() {

        // given
        String userId = UUID.randomUUID().toString();
        // when
        userService.deleteById(userId);
        // then
        verify(userRepository).deleteById(userId);
    }

    @Test
    public void shouldAddUserMailOrPhone() {

        //given
        String userId = UUID.randomUUID().toString();
        UserView userView = newRandomUserView(userId);
        User user = newRandomUser(userId);
        given(userRepository.findById(userId)).willReturn(Optional.of(user));
        //when
        userService.addUserMailOrPhone(userView);
        //then
        verify(userRepository).save(user);
    }

    @Test
    public void updateUserMailOrPhone() {

        //given
        String userId = UUID.randomUUID().toString();
        UserView userView = newRandomUserView(userId);
        User user = newRandomUser(userId);
        given(userRepository.findById(userId)).willReturn(Optional.of(user));
        //when
        userService.updateExistingUserMailOrPhone(userView);
        //then
        verify(userRepository).save(user);
    }

    @Test
    public void shouldReturnUserWhenUserNameFound() {

        //given
        String userId = UUID.randomUUID().toString();
        User expectedUser = newRandomUser(userId);
        String firstName = expectedUser.getFirstName();
        String lastName = expectedUser.getFirstName();
        given(userRepository.findByName(firstName, lastName)).willReturn(Optional.of(expectedUser));

        //when
        User actualUser = userService.getUserByName(firstName, lastName);
        //then
        assertThat(actualUser, is(expectedUser));
    }

}
