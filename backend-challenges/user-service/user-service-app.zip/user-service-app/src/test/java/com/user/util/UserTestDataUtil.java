package com.user.util;


import com.user.entity.Email;
import com.user.entity.PhoneNumber;
import com.user.entity.User;
import com.user.view.EmailView;
import com.user.view.PhoneNumberView;
import com.user.view.UserView;
import org.apache.commons.lang3.RandomStringUtils;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class UserTestDataUtil {

    public static User newRandomUser(String id) {
        return User.builder()
                .id(id)
                .firstName(randomString())
                .lastName(randomString())
                .phoneNumberSet(newRandomPhoneNumberSet())
                .emailSet(newRandomEmailSet())
                .build();
    }


    public static Set<PhoneNumber> newRandomPhoneNumberSet() {
        Set<PhoneNumber> phoneNumberSet = new HashSet<>();
        phoneNumberSet.add(PhoneNumber.builder().number(randomString()).id(randomInt()).build());
        return phoneNumberSet;
    }

    public static Set<Email> newRandomEmailSet() {
        Set<Email> emailSet = new HashSet<>();
        emailSet.add(Email.builder().mail(randomString()).id(randomInt()).build());
        return emailSet;
    }

    public static UserView newRandomUserView(String id) {
        return UserView.builder()
                .id(id)
                .firstName(randomString())
                .lastName(randomString())
                .phoneNumberSet(newRandomPhoneNumberViewSet())
                .emailSet(newRandomEmailViewSet())
                .build();
    }

    public static Set<PhoneNumberView> newRandomPhoneNumberViewSet() {
        Set<PhoneNumberView> phoneNumberSet = new HashSet<>();
        phoneNumberSet.add(PhoneNumberView.builder().number(randomString()).id(randomInt()).build());
        return phoneNumberSet;
    }

    public static Set<EmailView> newRandomEmailViewSet() {
        Set<EmailView> emailSet = new HashSet<>();
        emailSet.add(EmailView.builder().mail(randomString()).id(randomInt()).build());
        return emailSet;
    }

    public static String randomString() {
        return RandomStringUtils.randomAlphabetic(10);
    }

    public static int randomInt() {
        Random random = new Random();
        return random.nextInt(50);
    }
}
