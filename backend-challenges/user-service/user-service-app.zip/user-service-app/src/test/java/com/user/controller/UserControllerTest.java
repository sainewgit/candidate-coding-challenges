package com.user.controller;

import com.user.entity.User;
import com.user.service.UserService;
import com.user.transformer.ToUserViewTransformer;
import com.user.view.UserView;
import org.junit.After;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.UUID;

import static com.shazam.shazamcrest.MatcherAssert.assertThat;
import static com.shazam.shazamcrest.matcher.Matchers.sameBeanAs;
import static com.user.util.UserTestDataUtil.newRandomUser;
import static com.user.util.UserTestDataUtil.newRandomUserView;
import static org.hamcrest.CoreMatchers.is;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class UserControllerTest {

    @Mock
    private UserService userService;

    @Mock
    private ToUserViewTransformer toUserViewTransformer;

    @InjectMocks
    private UserController userController;

    @After
    public void afterTest() {
        reset(userService);
        reset(toUserViewTransformer);
    }

    @Test
    public void shouldReturnUserWhenUserIDFound() {

        //given
        String userId = UUID.randomUUID().toString();
        User user = newRandomUser(userId);
        UserView expectedUserView = newRandomUserView(userId);

        given(userService.getUserById(userId)).willReturn(user);
        given(toUserViewTransformer.transformUserToUserView(user)).willReturn(expectedUserView);

        //when
        ResponseEntity<UserView> actualUser = userController.getUserById(userId);

        //then
        assertThat(actualUser.getStatusCode(), is(HttpStatus.OK));
        assertThat(actualUser.getBody(), sameBeanAs((expectedUserView)));

    }

    @Test
    public void shouldCreateUser() {
        //given
        String userId = UUID.randomUUID().toString();
        String expectedUserMsg = "User Created Successfully  id::" + userId;
        UserView expectedUserView = newRandomUserView(userId);
        User user = newRandomUser(userId);
        given(toUserViewTransformer.transformUserViewToUser(expectedUserView)).willReturn(user);
        given(userService.saveUser(user)).willReturn(userId);
        //when
        ResponseEntity<String> actualUserId = userController.createUser(expectedUserView);
        //then
        assertThat(actualUserId.getStatusCode(), is(HttpStatus.CREATED));
        assertThat(actualUserId.getBody(), is(expectedUserMsg));
    }

    @Test
    public void shouldDeleteUserWhenMatchFound() {

        // given
        String userId = UUID.randomUUID().toString();
        // when
        ResponseEntity result = userController.deleteUserById(userId);
        // then
        verify(userService).deleteById(userId);
        assertThat(result.getStatusCode(), is(HttpStatus.NO_CONTENT));
    }

    @Test
    public void shouldReturnUserWhenUserNameFound() {

        //given
        String userId = UUID.randomUUID().toString();
        UserView expectedUserView = newRandomUserView(userId);
        User user = newRandomUser(userId);
        String firstName = expectedUserView.getFirstName();
        String lastName = expectedUserView.getFirstName();

        given(userService.getUserByName(firstName, lastName)).willReturn(user);
        given(toUserViewTransformer.transformUserToUserView(user)).willReturn(expectedUserView);
        // when
        ResponseEntity<UserView> result = userController.getUserByName(firstName, lastName);
        // then

        assertThat(result.getStatusCode(), is(HttpStatus.OK));
        assertThat(result.getBody(), sameBeanAs((expectedUserView)));
    }

}
