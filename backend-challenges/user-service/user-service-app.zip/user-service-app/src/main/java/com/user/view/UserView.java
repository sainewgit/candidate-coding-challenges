package com.user.view;

import com.user.entity.PhoneNumber;
import lombok.Builder;
import lombok.Data;

import java.util.Set;


@Data
@Builder
public class UserView {

    private String id;
    private String lastName;
    private String firstName;
    private Set<EmailView> emailSet;
    private Set<PhoneNumberView> phoneNumberSet;
}
