package com.user.repository;

import com.user.entity.User;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;
/**
 * UserRepository is used perform some  Mongo  db operation
 */
@Repository
public interface UserRepository extends MongoRepository<User, String> {

    @Query("{firstName: ?0, lastName: ?1}")
    Optional<User> findByName(String firstName, String lastName);
}
