package com.user.service;

import com.user.entity.Email;
import com.user.entity.PhoneNumber;
import com.user.entity.User;
import com.user.exception.UserNotFoundException;
import com.user.repository.UserRepository;
import com.user.transformer.ToUserViewTransformer;
import com.user.view.EmailView;
import com.user.view.PhoneNumberView;
import com.user.view.UserView;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.Set;

/**
 * UserService used for perform some User service logic
 */
@Service
@Slf4j
public class UserService {

    private UserRepository userRepository;
    private ToUserViewTransformer toUserViewTransformer;

    @Autowired
    public UserService(UserRepository userRepository, ToUserViewTransformer toUserViewTransformer) {
        this.userRepository = userRepository;
        this.toUserViewTransformer = toUserViewTransformer;
    }

    /**
     * save User in repo
     *
     * @param user input user
     * @return string
     */
    public String saveUser(User user) {
        User savedUser = userRepository.save(user);
        return savedUser.getId();
    }

    /**
     * Get a  User by id
     *
     * @param id input id
     * @return User
     */
    public User getUserById(String id) {
        Optional<User> user = userRepository.findById(id);
        return user.orElseThrow(() -> new UserNotFoundException("cannot find User with id:" + id));
    }

    /**
     * delete a  User by id
     *
     * @param id input log id
     */
    public void deleteById(String id) {
        userRepository.deleteById(id);

    }

    /**
     * Get a  User by Name
     *
     * @param firstName input firstName
     * @param lastName  input lastName
     * @return User
     */
    public User getUserByName(String firstName, String lastName) {
        Optional<User> user = userRepository.findByName(firstName, lastName);
        return user.orElseThrow(() -> new UserNotFoundException("cannot find User with name:" + "firstName:" + firstName + "lastName:" + lastName));
    }

    /**
     * addUserMailOrPhone User in repo
     *
     * @param userView input user
     */
    public void addUserMailOrPhone(UserView userView) {
        User user = getUserById(userView.getId());
        if (userView.getEmailSet() != null && userView.getEmailSet().size() != 0) {
            Set<Email> newUserEmailSet = toUserViewTransformer.transformEmailViewToEmail(userView.getEmailSet());
            user.getEmailSet().addAll(newUserEmailSet);
        }
        if (userView.getPhoneNumberSet() != null && userView.getPhoneNumberSet().size() != 0) {
            Set<PhoneNumber> newPhoneNumberSet = toUserViewTransformer.transformPhoneViewToPhone(userView.getPhoneNumberSet());
            user.getPhoneNumberSet().addAll(newPhoneNumberSet);
        }
        userRepository.save(user);
    }

    /**
     * updateExistingUserMailOrPhone User in repo
     *
     * @param userView input user
     */
    public void updateExistingUserMailOrPhone(UserView userView) {
        User user = getUserById(userView.getId());
        if (userView.getEmailSet() != null && userView.getEmailSet().size() != 0) {
            Set<Email> savedEmailSet = user.getEmailSet();
            Set<EmailView> updatedEmailSet = userView.getEmailSet();
            updatedEmailSet.forEach(updatedEmail ->
            {
                savedEmailSet.forEach(savedEmail ->
                {
                    if (updatedEmail.getId() == savedEmail.getId()) savedEmail.setMail(updatedEmail.getMail());
                });
            });

        }
        if (userView.getPhoneNumberSet() != null && userView.getPhoneNumberSet().size() != 0) {
            Set<PhoneNumber> savedPhoneNumberSet = user.getPhoneNumberSet();
            Set<PhoneNumberView> updatedPhoneNumberSet = userView.getPhoneNumberSet();
            updatedPhoneNumberSet.forEach(updatedPhoneNumber ->
            {
                savedPhoneNumberSet.forEach(savedPhoneNumber -> {
                    if (savedPhoneNumber.getId() == updatedPhoneNumber.getId())
                        savedPhoneNumber.setNumber(updatedPhoneNumber.getNumber());
                });
            });
        }
        userRepository.save(user);
    }
}
