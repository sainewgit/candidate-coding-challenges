package com.user;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * UserServiceApplication is Use for perform some User Management Related operation
 */
@SpringBootApplication
@OpenAPIDefinition(info = @Info(title = "UserServiceApplication", description = "UserServiceApplication"))
public class UserServiceAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(UserServiceAppApplication.class, args);
    }

}
