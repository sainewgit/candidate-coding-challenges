package com.user.transformer;

import com.user.entity.Email;
import com.user.entity.PhoneNumber;
import com.user.entity.User;
import com.user.view.EmailView;
import com.user.view.PhoneNumberView;
import com.user.view.UserView;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Set;
import java.util.stream.Collectors;

/**
 * ToUserViewTransformer used for transform User to User view or vice-versa
 */
@Component
@Slf4j
public class ToUserViewTransformer {

    /**
     * it will  transformUserViewToUser
     *
     * @param userView
     * @return User
     */
    public User transformUserViewToUser(UserView userView) {
        return User.builder()
                .firstName(userView.getFirstName())
                .lastName(userView.getLastName())
                .emailSet(transformEmailViewToEmail(userView.getEmailSet()))
                .phoneNumberSet(transformPhoneViewToPhone(userView.getPhoneNumberSet())).
                build();
    }

    /**
     * it will  transformEmailViewToEmail
     *
     * @param emailSet
     * @return Email
     */
    public Set<Email> transformEmailViewToEmail(Set<EmailView> emailSet) {
        return emailSet.stream().map(e -> Email.builder().id(e.getId()).mail(e.getMail()).build()
        ).collect(Collectors.toSet());
    }

    /**
     * it will  transformPhoneViewToPhone
     *
     * @param phoneNumberViewSet
     * @return PhoneNumber
     */
    public Set<PhoneNumber> transformPhoneViewToPhone(Set<PhoneNumberView> phoneNumberViewSet) {
        return phoneNumberViewSet.stream().map(p -> PhoneNumber.builder().id(p.getId()).number(p.getNumber()).build()).collect(Collectors.toSet());
    }

    /**
     * it will  transformUserToUserView
     *
     * @param user
     * @return UserView
     */
    public UserView transformUserToUserView(User user) {
        return UserView.builder()
                .id(user.getId())
                .firstName(user.getFirstName())
                .lastName(user.getLastName())
                .emailSet(transformEmailToEmailView(user.getEmailSet()))
                .phoneNumberSet(transformPhoneToPhoneView(user.getPhoneNumberSet()))
                .build();
    }

    /**
     * it will  transformEmailToEmailView
     *
     * @param emailSet
     * @return EmailView
     */
    private Set<EmailView> transformEmailToEmailView(Set<Email> emailSet) {
        return emailSet.stream().map(e -> EmailView.builder().id(e.getId()).mail(e.getMail()).build()
        ).collect(Collectors.toSet());
    }

    /**
     * it will  transformPhoneToPhoneView
     *
     * @param phoneNumberSet
     * @return PhoneNumberView
     */
    private Set<PhoneNumberView> transformPhoneToPhoneView(Set<PhoneNumber> phoneNumberSet) {
        return phoneNumberSet.stream().map(p -> PhoneNumberView.builder().id(p.getId()).number(p.getNumber()).build()).collect(Collectors.toSet());
    }
}
