package com.user.view;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EmailView {
    private int id;
    private String mail;
}
