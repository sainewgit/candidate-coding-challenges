package com.user.controller;

import com.user.entity.User;
import com.user.service.UserService;
import com.user.transformer.ToUserViewTransformer;
import com.user.view.UserView;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

/**
 * UserController is Use for provide  all User  operations
 */
@RestController
@RequestMapping("/users")
@Slf4j
public class UserController {

    private UserService userService;
    private ToUserViewTransformer toUserViewTransformer;

    @Autowired
    public UserController(UserService userService, ToUserViewTransformer toUserViewTransformer) {
        this.userService = userService;
        this.toUserViewTransformer = toUserViewTransformer;
    }

    @Operation(summary = "createUser")
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "It is used to create user in database",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = String.class))})})

    @PostMapping
    public ResponseEntity<String> createUser(@RequestBody UserView userView) {
        String userId = userService.saveUser(toUserViewTransformer.transformUserViewToUser(userView));
        return new ResponseEntity<>("User Created Successfully  id::" + userId, HttpStatus.CREATED);
    }

    @Operation(summary = "Get a  User by userId")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "It should provide  user by id",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = UserView.class))})})

    @GetMapping("/{id}")
    public ResponseEntity<UserView> getUserById(@PathVariable String id) {
        User user = userService.getUserById(id);
        return new ResponseEntity<>(toUserViewTransformer.transformUserToUserView(user), HttpStatus.OK);
    }

    @Operation(summary = "delete  User by id")
    @ApiResponses(value = {@ApiResponse(responseCode = "204", description = "It should delete   user by id",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = void.class))})})

    @DeleteMapping("/{id}")
    public ResponseEntity deleteUserById(@PathVariable String id) {
        userService.getUserById(id);
        userService.deleteById(id);
        return new ResponseEntity(HttpStatus.NO_CONTENT);
    }

    @Operation(summary = "Get a  User by ByName")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "It should provide  user ByName",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = UserView.class))})})

    //Note: Name= assuming firstname and lastname
    //request firstname and lastName
    @GetMapping("/name")
    public ResponseEntity<UserView> getUserByName(@RequestParam String firstName, @RequestParam String lastName) {
        User user = userService.getUserByName(firstName, lastName);
        return new ResponseEntity<>(toUserViewTransformer.transformUserToUserView(user), HttpStatus.OK);
    }

    @Operation(summary = "addUserMailOrPhone ")
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "It is used to addUserMailOrPhone  in database",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = String.class))})})

    @PostMapping("/add-user-data")
    public ResponseEntity<String> addUserMailOrPhone(@RequestBody UserView userView) {
        userService.addUserMailOrPhone(userView);
        return new ResponseEntity<>("Successfully Added UserMailOrPhone", HttpStatus.CREATED);

    }

    @Operation(summary = "updateUserMailOrPhone ")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "It is used to updateUserMailOrPhone  in database",
            content = {@Content(mediaType = "application/json", schema = @Schema(implementation = String.class))})})

    @PutMapping("/update-user-data")
    public ResponseEntity<String> updateUserMailOrPhone(@RequestBody UserView userView) {
        userService.updateExistingUserMailOrPhone(userView);
        return ResponseEntity.of(Optional.of("Successfully updated UserMailOrPhone"));
    }

}
